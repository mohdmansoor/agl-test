import React, { Component } from 'react';

class App extends Component {
	state = {
    agldata: [],
	maleCats:[],
	femaleCats:[]
  }
  componentDidMount() {
	  let mcats = [];
	  let fCats = [];
    fetch('http://agl-developer-test.azurewebsites.net/people.json')
    .then(res => res.json())
    .then((data) => {	
		if(data.pets !== null && data.pets !== '') {
			//logic goes here 
			// add to the variable and sort
			//set mcats to maleCats
			//set fcats to femaleCats
						
		}
      this.setState({ agldata: data })
	  console.log(this.state.agldata)
    })
    .catch(console.log)
  }


  
  // [...]
  
  render() {
	  
    return (
      <div>
        {this.state.agldata.map((todo) => {
			if(todo.pets !== null && todo.pets !== '') {
				
          return <div  className="card">
            <div className="card-body">
              <h1>{todo.name}</h1>
			  <p>{todo.gender}</p>
			  <p>{todo.age}</p>
			  {todo.pets.map((pet)=> {
                    return (
                        <div><p>{pet.name}</p>
						<p>{pet.type}</p>
						</div>
                    )
						})}
				
            </div>
          </div>
        }
		}
		)}      
        
    </div>

    );
  }
  
  
}
export default App;